import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit
{
  // ContactForm = new FormGroup(
  //   {
  //     firstname : new FormControl('', [Validators.required]),
  //     lastname : new FormControl('', [Validators.required]),
  //     emailID : new FormControl('', [Validators.required]),
  //     phone : new FormControl('', [Validators.required]),
  //     address : new FormControl('', [Validators.required])
  //   }
  // );
  states : any=[];
  selectedValue:any;

  constructor(private _fbobj : FormBuilder)
  {}
  
  ngOnInit(): void 
  {
    this.states =  [
      {Id : "Maharashtra", Name:"Maharashtra"},
      {Id : "Gujarat", Name:"Gujarat"},
      {Id : "Uttar Pradesh", Name:"Uttar Pradesh"}
    ];
  }

  ContactForm = this._fbobj.group(
    {
      firstname : ['', [Validators.required, Validators.pattern("^[a-zA-Z]+$")]],
      lastname : ['', [Validators.required, Validators.pattern("^[a-zA-Z]+$")]],
      emailID : ['', [Validators.required, Validators.pattern("^[a-zA-Z0-9+_.-]+@[a-zA-Z0-9.-]+$"), Validators.minLength(2)]],
      phone : ['', [ Validators.required,
        Validators.pattern("^[0-9]*$"),
        Validators.minLength(10), Validators.maxLength(10)]],
      address : ['', Validators.required],
      city : ['', [Validators.required, Validators.minLength(4), , Validators.pattern("^[a-zA-Z]+$")]],
      state : ['', Validators.required],
      zipcode : ['', [Validators.required, Validators.minLength(5)]],
      comments : ['', [Validators.required, Validators.minLength(30)]],

    }
  )
}
