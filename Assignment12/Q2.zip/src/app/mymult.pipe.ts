import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'mymult'
})
export class MymultPipe implements PipeTransform 
{
  transform(value : number, Param : string): number 
  {
    var result : number = 0;
    var num : number = parseInt(Param);
    result = value * num;
    return result;
  }
}
