import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'myadd'
})
export class MyaddPipe implements PipeTransform 
{
  transform(value: number, param : string): number 
  {
    var result : number = 0;
    var num : number = parseInt(param);
    result = value + num; 
    return result;
  }
}
