import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'myRev'
})
export class MyRevPipe implements PipeTransform 
{
  transform(value: string): string 
  {
    var temp : string = "";
    var cnt : number = 0;

    for(cnt = value.length-1; cnt >= 0; cnt--)
    {
      temp = temp + value[cnt];
    }
    return temp;
  }
}
