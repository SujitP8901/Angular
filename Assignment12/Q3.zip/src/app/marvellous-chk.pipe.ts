import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'marvellousChk'
})
export class MarvellousChkPipe implements PipeTransform 
{
  transform(value: number, Param : string): String 
  {
    var str : string = "";

    if(Param == "Prime")
    {
      var cnt : number = 0;

      for(cnt = 2; cnt <= value/2; cnt++)
      {
        if((value % cnt) == 0)
        {
          break;
        }
      }

      if(cnt > value/2)
      {
        str = "It is a Prime Number";
      }
      else
      {
        str = "It is not a Prime Number";
      }
    }
    
    if(Param == "Perfect")
    {
      var cnt : number = 0;
      var add : number = 0;

      for(cnt = 1; cnt <= value/2; cnt++)
      {
        if((value % cnt) == 0)
        {
          add = add + cnt;
        }
      }

      if(add == value)
      {
        str = "It is Perfect Number";
      }
      else
      {
        str = "It is not Perfect Number";
      }
    }
    
    if(Param == "Even")
    {
      if((value % 2) == 0)
      {
        str = "It is Even Number";
      }
      else
      {
        str = "It is not Even Number";
      }
    }

    if(Param == "Odd")
    {
      if((value % 2) != 0)
      {
        str = "It is Odd Number";
      }
      else
      {
        str = "It is not Odd Number";
      }
    }
    return str;
  }
}
