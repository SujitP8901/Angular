import { Component, OnInit } from '@angular/core';
import { ArithmeticService } from '../arithmetic.service';
@Component({
  selector: 'app-demo',
  template: `
    <h1> Addition is : {{retAdd}} </h1>
    <h1> Subtraction is : {{retSub}} </h1>
  `
})
export class DemoComponent implements OnInit 
{
  public retAdd : any;
  public retSub : any;
  constructor(private _obj : ArithmeticService) { }
  ngOnInit(): void 
  {
    this.retAdd = this._obj.Add(11, 10);
    this.retSub = this._obj.Sub(11, 10);
  }
}
