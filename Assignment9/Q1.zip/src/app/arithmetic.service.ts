import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class ArithmeticService 
{
  constructor() { }
  public Add (no1 : number, no2 : number) : number
  {
    var ans : number;
    ans = no1 + no2;
    return ans;
  } 
  public Sub (no1 : number, no2 : number) : number
  {
    var ans : number;
    ans = no1 - no2;
    return ans;
  }
}
