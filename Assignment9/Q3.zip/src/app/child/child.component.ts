import { Component, OnInit } from '@angular/core';
import { NumberService } from '../number.service';
import { StringService } from '../string.service';

@Component({
  selector: 'app-child',
  template: `
    <h1>Capital Letters in "Marvellous InfoSystemS" : {{count}} </h1>
    <ng-template #Prime>
      <h1>Given Number is Prime Number</h1>
    </ng-template>

    <ng-template #NonPrime>
      <h1>Given Number is Not a Prime Number</h1>
    </ng-template>

    <h1 *ngIf = "ret; then Prime; else NonPrime"> </h1>
  `
})
export class ChildComponent implements OnInit 
{
  public ret : any;
  public count : any;

  constructor(private _nobj : NumberService, private _sobj : StringService) { }

  ngOnInit(): void 
  {
    this.count = this._sobj.CountCapital("Marvellous InfoSystemS");

    this.ret = this._nobj.ChkPrime(12);
  }

}
