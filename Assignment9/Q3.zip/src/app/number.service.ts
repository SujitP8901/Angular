import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class NumberService 
{
  public flag : any;
  constructor() { }

  public ChkPrime(no : number) : boolean
  {
    var cnt : number = 0;
    for(cnt = 2; cnt <= no/2; cnt++)
    {
      if((no % cnt) == 0)
      {
        this.flag = false;
        break;
      }
    }
    if(cnt > no/2)
    {
      this.flag = true;
    }
    return this.flag;
  }
}
