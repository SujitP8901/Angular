import { Component, OnInit } from '@angular/core';
import { StringService } from '../string.service';

@Component({
  selector: 'app-child2',
  template: `
    <h1>Capital Letters in "MarVeLloUs InfoSystemS" : {{ret}} </h1>
  `
})
export class Child2Component implements OnInit 
{
  public ret : any; 
  constructor(private _sobj : StringService) { }
  ngOnInit(): void 
  {
    this.ret = this._sobj.CountCapital("MarVeLloUs InfoSystemS");
  }

}
