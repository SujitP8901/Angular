import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class StringService 
{
  public str : any;
  constructor() { }

  public CountCapital(data : string) : number
  {
    this.str = data;
    var cnt : number = 0;
    var capCnt : number = 0;

    for(cnt = 0; cnt < this.str.length; cnt++)
    {
      if((this.str[cnt] >= 'A') && (this.str[cnt] <= 'Z'))
      {
        capCnt++;
      }
    }

    return capCnt;
  }
}
