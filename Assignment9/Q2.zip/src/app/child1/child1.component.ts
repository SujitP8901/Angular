import { Component, OnInit } from '@angular/core';
import { NumberService } from '../number.service';

@Component({
  selector: 'app-child1',
  template: `
    <ng-template #True>
      <h1>Prime Number</h1>
    </ng-template>

    <ng-template #False>
      <h1>Non Prime Number</h1>
    </ng-template>
    
    <h1 *ngIf = "ret; then True; else False"></h1>
  `
})
export class Child1Component implements OnInit 
{
  public ret : any;
  constructor(private _nobj : NumberService) { }

  ngOnInit(): void 
  {
    this.ret = this._nobj.ChkPrime(11);
  }

}
