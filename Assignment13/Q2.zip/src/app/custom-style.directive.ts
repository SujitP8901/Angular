import { Directive, ElementRef } from '@angular/core';

@Directive({
  selector: '[appCustomStyle]'
})
export class CustomStyleDirective 
{
  constructor(private _obj : ElementRef) 
  { 
    _obj.nativeElement.style.background = 'yellow';

  }
}
