import { Component } from '@angular/core';
import { FormControl, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent 
{
  ContactForm = new FormGroup(
    {
      firstname : new FormControl('', [Validators.required]),
      lastname : new FormControl('', [Validators.required]),
      emailID : new FormControl('', [Validators.required]),
      phone : new FormControl('', [Validators.required]),
      address : new FormControl('', [Validators.required])
    }
  );
}
